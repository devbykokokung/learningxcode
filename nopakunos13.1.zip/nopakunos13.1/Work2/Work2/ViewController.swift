//
//  ViewController.swift
//  Work2
//
//  Created by MAC923_52 on 23/1/2566 BE.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputNumber: UITextField!
    @IBOutlet weak var labelOutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSubmit(_ sender: Any) {
        let sum = Int(inputNumber.text!)! * Int(inputNumber.text!)!
        labelOutput.text = "\(sum)"
    }

}

